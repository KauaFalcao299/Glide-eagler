Thank you for downloading my resource pack (remember to read the credits file).
This text contains some important notices regarding the resource pack.

Useful information:

1) This resource pack works (preferably at higher versions like 1.21+), although the game sometimes reports it as incompatible.

2) The armor model tweaks can only be seen using version 1.21.

3) This resource pack was developed to work independently, so we cannot guarantee that you won't encounter problems when using it in conjunction with other packs. However, theoretically, if the packs don't modify the same things, the pack should work perfectly.

4) If something is wrong with the resource pack, please let me know so I can try to resolve the issue.

This resource pack is BUILD from @aimluca on discord, remember that he just takes some features from some cool pack and combines them into this pack.
If you have any problems, please feel free to contact me
[ Discord Link: https://discord.gg/nysk29TE8V ]